

const streetType = [
  { value: "alley", label: "Alley" },
  { value: "avenue", label: "Avenue" },
  { value: "boulevard", label: "Boulevard" },
  { value: "circuit", label: "Circuit" },
  { value: "close", label: "Close" },
  { value: "crescent", label: "Crescent" },
  { value: "drive", label: "Drive" },
  { value: "esplanade", label: "Esplanade" },
  { value: "freeway", label: "Freeway" },
  { value: "highway", label: "Highway" },
  { value: "lane", label: "Lane" },
  { value: "parade", label: "Parade" },
  { value: "place", label: "Place" },
  { value: "road", label: "Road" },
  { value: "street", label: "Street" },
  { value: "terrace", label: "Terrace" },
  { value: "way", label: "Way" },
];

export default streetType;