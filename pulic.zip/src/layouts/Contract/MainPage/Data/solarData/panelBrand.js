const panelBrand = [
  {
    value: "longi",
    lable: "Longi",
    subModel: [
      { value: "modelLongi1", lable: "Model:1 Longi", pricePerWatt: 0.43, capacity: 0.415 },
      { value: "modelLongi2", lable: "Model:2 Longi", pricePerWatt: 0.43, capacity: 0.415 },
    ],
  },
  {
    value: "twSolar",
    lable: "TW Solar",
    subModel: [
      { value: "modelTw1", lable: "Model:1 TW Solar", pricePerWatt: 0.43, capacity: 0.415 },
      { value: "modelTw2", lable: "Model:2 TW Solar", pricePerWatt: 0.43, capacity: 0.415 },
    ],
  },
  {
    value: "jinko",
    lable: "Jinko",
    subModel: [
      { value: "modelJinko1", lable: "Model:1 Jinko", pricePerWatt: 0.43, capacity: 0.415 },
      { value: "modelJinko2", lable: "Model:2 Jinko", pricePerWatt: 0.43, capacity: 0.415 },
    ],
  },
];

export default panelBrand;
