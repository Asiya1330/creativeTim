const unitType = [
  { value: "antenna", label: "Antenna" },
  { value: "apartment", label: "Apartment" },
  { value: "block", label: "Block" },
  { value: "building", label: "Building" },
  { value: "community_center", label: "Community Center" },
  { value: "farm", label: "Farm" },
  { value: "garage", label: "Garage" },
  { value: "hospital", label: "Hospital" },
  { value: "hotel", label: "Hotel" },
  { value: "house", label: "House" },
  { value: "park", label: "Park" },
  { value: "school", label: "School" },
  { value: "warehouse", label: "Warehouse" },
];
export default unitType;
